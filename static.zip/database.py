import sqlite3
from werkzeug.security import generate_password_hash

def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Users Table
    cursor.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, role TEXT)')
    
    # Customers Table: Added total_spent to track loyalty
    cursor.execute('''CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        name TEXT, 
        phone TEXT, 
        email TEXT, 
        address TEXT DEFAULT "Not Provided", 
        status TEXT DEFAULT "Regular",
        total_spent REAL DEFAULT 0
    )''')
    
    # Products Table: Added cost_price to track expenses
    cursor.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        name TEXT, 
        price REAL, 
        cost_price REAL DEFAULT 0,
        stock INTEGER
    )''')
    
    # Orders Table
    cursor.execute('CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, product_id INTEGER, quantity INTEGER, total_price REAL, date TEXT, status TEXT DEFAULT "Delivered")')
    
    # Leads Table
    cursor.execute('CREATE TABLE IF NOT EXISTS leads (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, contact TEXT, notes TEXT, assigned_to TEXT, status TEXT DEFAULT "Pending")')
    
    # Interactions Table
    cursor.execute('CREATE TABLE IF NOT EXISTS interactions (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, type TEXT, note TEXT, date TEXT)')

    # Default Admin
    admin_pw = generate_password_hash('admin123')
    cursor.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)", ('admin', admin_pw, 'Admin'))

    conn.commit()
    conn.close()
    print("Database Initialized with Expense and Loyalty tracking!")

if __name__ == "__main__":
    init_db()
import sqlite3

def fix_database():
    try:
        conn = sqlite3.connect('database.db')
        # This adds the missing 'notes' column to your interactions table
        conn.execute("ALTER TABLE interactions ADD COLUMN notes TEXT")
        conn.commit()
        conn.close()
        print("✅ Success! The 'notes' column has been added.")
    except Exception as e:
        print(f"❌ Error: {e} (The column might already exist)")

if __name__ == "__main__":
    fix_database()
import sqlite3

def upgrade():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    print("Starting database update...")
    
    try:
        # Add the cost_price column to track your lighting expenses
        cursor.execute('ALTER TABLE products ADD COLUMN cost_price REAL DEFAULT 0')
        print("✅ Added 'cost_price' to Products table.")
    except sqlite3.OperationalError:
        print("ℹ️ 'cost_price' already exists, skipping.")

    try:
        # Add the total_spent column to track customer loyalty
        cursor.execute('ALTER TABLE customers ADD COLUMN total_spent REAL DEFAULT 0')
        print("✅ Added 'total_spent' to Customers table.")
    except sqlite3.OperationalError:
        print("ℹ️ 'total_spent' already exists, skipping.")

    conn.commit()
    conn.close()
    print("Database update complete! You can now run app.py.")

if __name__ == "__main__":
    upgrade()